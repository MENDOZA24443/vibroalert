import pyrebase
global id_config
id_config="39572a0e5a324a06b44197032528667c"
id_maquina="66f3d96253a04b31a77bce76bf6640e7"
id_empresa="df67d96e7c9c45d78b343be310b8361a"
id_zona="3f5908b2a45f467da169cc0e540d218e"
ip_address="192.168.0.78"
n_empresa="Vibromontajes"
n_zona="Sur"
global inside_of

firebaseConfig = {
    "apiKey": "AIzaSyDvBHrU2d7NUPgOoCUG9FkbPno8FCsPEWU",
    "authDomain": "spectrum-db-638c4.firebaseapp.com",
    "databaseURL": "https://spectrum-db-638c4-default-rtdb.firebaseio.com",
    "projectId": "spectrum-db-638c4",
    "storageBucket": "spectrum-db-638c4.appspot.com",
    "messagingSenderId": "682924367494",
    "appId": "1:682924367494:web:71f74cf4981c63607e3b07",
    "measurementId": "G-TH61F32YYD"
  }
garray=[]
email="pyrebaseprueba@vibro.com"
password="Vibro_pi"
firebase=pyrebase.initialize_app(firebaseConfig)
db=firebase.database()
auth=firebase.auth()
todo=db.child(f"configuraciones/{id_config}").get()
print("todo",todo)
# print("to",todo.val())
# channels_on=db.child(f"configuraciones/{id_config}/Nro_canales").get()
# print("channel_on",channels_on.val())    
# if  channels_on.val()!= None: 
#   print("inside None configuraciones")
#   delay =1

garray.append(db.child(f"configuraciones/{id_config}/canales/canal_{1}/ganancia").get().val())
print("garray",garray)
# user=auth.sign_in_with_email_and_password()
# user=auth.create_user_with_email_and_password(email,password)
user=auth.sign_in_with_email_and_password(email,password)
# info=auth.get_account_info(user['idToken'])
# print("info",info)
print("user",user['localId'])


# var firebaseConfig = {
#   apiKey: "API_KEY",
#   authDomain: "PROJECT_ID.firebaseapp.com",
#   // The value of `databaseURL` depends on the location of the database
#   databaseURL: "https://DATABASE_NAME.firebaseio.com",
#   projectId: "PROJECT_ID",
#   storageBucket: "PROJECT_ID.appspot.com",
#   messagingSenderId: "SENDER_ID",
#   appId: "APP_ID",
#   // For Firebase JavaScript SDK v7.20.0 and later, `measurementId` is an optional field
#   measurementId: "G-MEASUREMENT_ID",
# };

# import firebase_admin
# from firebase_admin import credentials, db
# from flask import *
# global id_config
# id_config="39572a0e5a324a06b44197032528667c"
# id_maquina="66f3d96253a04b31a77bce76bf6640e7"
# id_empresa="df67d96e7c9c45d78b343be310b8361a"
# id_zona="3f5908b2a45f467da169cc0e540d218e"
# ip_address="192.168.0.78"
# n_empresa="Vibromontajes"
# n_zona="Sur"
# global inside_of

# cred = credentials.Certificate("/home/pi/env_flask/spectrum-db.json")

# # firebase_admin.initialize_app(cred)

# firebase_admin.initialize_app(cred, {
#     'databaseURL': 'https://spectrum-db-638c4-default-rtdb.firebaseio.com/'
# })

# ref = db.reference()

# app= Flask(__name__)


# @app.route('/edit-config', methods=['GET', 'POST'])
# def edit_config():
#     cleaner={}
#     global namemachine
#     # todo=ref.child(f"Configuraciones/{id_config}").get()
#     # to= todo.keys()
#     # for l in to:
#     #     namemachine=l
#     namemachine="motor"
#     if request.method == 'POST':
#       #   ref.child(f'Configuraciones/{id_config}').set(cleaner)
#         namemachine= request.form['machinename']
#         ref.child(f'Configuraciones/{id_config}/id').set(f"{id_config}")
#         ref.child(f'Configuraciones/{id_config}/midiendo').set(False)
#         name= request.form['t_sensor']
#         ref.child(f'Configuraciones/{id_config}/tipoSensor').set(name)
#         ref.child(f'Configuraciones/{id_config}/maquina/id').set(f"{id_maquina}")
#         ref.child(f'Configuraciones/{id_config}/maquina/nombre').set(f"{namemachine}")
#         name= request.form['s_sensor']
#         ref.child(f'Configuraciones/{id_config}/sensibilidadSensor').set(name)
#         n_ch= request.form['canal']
#         ref.child(f'Configuraciones/{id_config}/Nro_canales').set(n_ch)
#         ref.child(f'Configuraciones/{id_config}/direccion_ip').set(ip_address)
#         if int(n_ch)<=4:
#             return render_template('ch_config.html', ch=n_ch)
#     ref.child(f'Configuraciones/{id_config}/midiendo').set(False)
#     return render_template('config.html')

# @app.route('/', methods=['GET', 'POST'])
# def home():
#         todo=ref.child(f"Configuraciones/{id_config}").get()
#         to= todo.values()
#         print(to)
#         return render_template('index.html',t=to)
    
# @app.route('/config', methods=['GET', 'POST'])
# def config():
#    if request.method == 'POST':
#         channel_1="off"
#         channel_2="off"
#         channel_3="off"
#         channel_4="off"
#         flV_ch1={}
#         flA_ch1={}
#         flV_ch2={}
#         flA_ch2={}
#         flV_ch3={}
#         flA_ch3={}
#         flV_ch4={}
#         flA_ch4={}
#         conf={}
#         emp={}
#         maq={}
#         for form in request.form:
        
#             if form=='direccion_ch1': channel_1="on"
#             elif form=='direccion_ch2':channel_2="on"
#             elif form=='direccion_ch3':channel_3="on"
#             elif form=='direccion_ch4': channel_4="on"
#             elif form=='k10_ch1':flA_ch1[form]=request.form[form]
#             elif form=='k5_ch1':flA_ch1[form]=request.form[form]
#             elif form=='k1_ch1':flV_ch1[form]=request.form[form]
#             elif form=='h5_ch1':flV_ch1[form]=request.form[form]
#             elif form=='k10_ch2':flA_ch2[form]=request.form[form]
#             elif form=='k5_ch2':flA_ch2[form]=request.form[form]
#             elif form=='k1_ch2':flV_ch2[form]=request.form[form]
#             elif form=='h5_ch2':flV_ch2[form]=request.form[form]
#             elif form=='k10_ch3':flA_ch3[form]=request.form[form]
#             elif form=='k5_ch3':flA_ch3[form]=request.form[form]
#             elif form=='k1_ch3':flV_ch3[form]=request.form[form]
#             elif form=='h5_ch3':flV_ch3[form]=request.form[form]
#             elif form=='k10_ch4':flA_ch4[form]=request.form[form]
#             elif form=='k5_ch4':flA_ch4[form]=request.form[form]
#             elif form=='k1_ch4':flV_ch4[form]=request.form[form]
#             elif form=='h5_ch4':flV_ch4[form]=request.form[form]

#         if channel_1=="on":
#             aux= request.form['direccion_ch1']
#             ref.child(f'Configuraciones/{id_config}/canales/canal_1/id/').set("canal_1")
#             ref.child(f'Configuraciones/{id_config}/canales/canal_1/direccion/').set(aux)
#             aux= request.form['punto_ch1']
#             ref.child(f'Configuraciones/{id_config}/canales/canal_1/nombre/').set(aux)
#             aux= request.form['g_ch1']
#             ref.child(f'Configuraciones/{id_config}/canales/canal_1/ganancia/').set(aux)
#             ref.child(f'Configuraciones/{id_config}/canales/canal_1/velocidad/').set(flV_ch1)
#             ref.child(f'Configuraciones/{id_config}/canales/canal_1/aceleracion/').set(flA_ch1)
#             ref.child(f'Configuraciones/{id_config}/canales/canal_1/habilitado/').set(True) 
#             emp[f'{id_empresa}']={
#                   'id':id_empresa,
#                   'nombre':n_empresa
#             }
#             maq[f'{id_maquina}']={
#                   'id':id_maquina,
#                   'nombre':namemachine,
#                   'empresa':{
#                   'id':id_empresa,
#                   'nombre':n_empresa
#                   },
#                   'zona':{
#                      f'{id_zona}':{
#                         'id':id_zona,
#                         'nombre':n_zona
#                      }
#                   }
#             }
#             ref.child(f'maquinas/').set(maq)
#             ref.child(f'empresas/').set(emp)

        

#         if channel_2=="on":
#             aux= request.form['direccion_ch2']
#             ref.child(f'Configuraciones/{id_config}/canales/canal_2/id/').set("canal_2")
#             ref.child(f'Configuraciones/{id_config}/canales/canal_2/direccion/').set(aux)
#             aux= request.form['punto_ch2']
#             ref.child(f'Configuraciones/{id_config}/canales/canal_2/nombre/').set(aux)
#             aux= request.form['g_ch2']
#             ref.child(f'Configuraciones/{id_config}/canales/canal_2/ganancia/').set(aux)
#             ref.child(f'Configuraciones/{id_config}/canales/canal_2/velocidad/').set(flV_ch2)
#             ref.child(f'Configuraciones/{id_config}/canales/canal_2/aceleracion/').set(flA_ch2)
#             ref.child(f'Configuraciones/{id_config}/canales/canal_2/habilitado/').set(True) 
#         else:
#             ref.child(f'Configuraciones/{id_config}/canales/canal_2/habilitado/').set(False)  

#         if channel_3=="on":
#             aux= request.form['direccion_ch3']
#             ref.child(f'Configuraciones/{id_config}/canales/canal_3/id/').set("canal_3")
#             ref.child(f'Configuraciones/{id_config}/canales/canal_3/direccion/').set(aux)
#             aux= request.form['punto_ch3']
#             ref.child(f'Configuraciones/{id_config}/canales/canal_3/nombre/').set(aux)
#             aux= request.form['g_ch3']
#             ref.child(f'Configuraciones/{id_config}/canales/canal_3/ganancia/').set(aux)
#             ref.child(f'Configuraciones/{id_config}/canales/canal_3/velocidad/').set(flV_ch3)
#             ref.child(f'Configuraciones/{id_config}/canales/canal_3/aceleracion/').set(flA_ch3)
#             ref.child(f'Configuraciones/{id_config}/canales/canal_3/habilitado/').set(True) 
#         else:
#             ref.child(f'Configuraciones/{id_config}/canales/canal_3/habilitado/').set(False)  

#         if channel_4=="on":
#             aux= request.form['direccion_ch4']
#             ref.child(f'Configuraciones/{id_config}/canales/canal_4/id/').set("canal_4")
#             ref.child(f'Configuraciones/{id_config}/canales/canal_4/direccion/').set(aux)
#             aux= request.form['punto_ch4']
#             ref.child(f'Configuraciones/{id_config}/canales/canal_4/nombre/').set(aux)
#             aux= request.form['g_ch4']
#             ref.child(f'Configuraciones/{id_config}/canales/canal_4/ganancia/').set(aux)
#             ref.child(f'Configuraciones/{id_config}/canales/canal_4/velocidad/').set(flV_ch4)
#             ref.child(f'Configuraciones/{id_config}/canales/canal_4/aceleracion/').set(flA_ch4)
#             ref.child(f'Configuraciones/{id_config}/canales/canal_4/habilitado/').set(True) 
#         else:
#             ref.child(f'Configuraciones/{id_config}/canales/canal_4/habilitado/').set(False)  

#         ref.child(f'Configuraciones/{id_config}/midiendo').set(True)
#         to=ref.child(f"Configuraciones/{id_config}/").get()
#         conf['nombre']=to['maquina']['nombre']
#         conf['tipoSensor']=to['tipoSensor']
#         conf['Nro_canales']=to['Nro_canales']
#         conf['sensibilidadSensor']=to['sensibilidadSensor']
#         if int(conf['Nro_canales'])>=1:
#             conf['nombre_ch1']=to['canales']['canal_1']['nombre']
#             conf['direccion_ch1']=to['canales']['canal_1']['direccion']
#             conf['ganancia_ch1']=to['canales']['canal_1']['ganancia']
#             if 'aceleracion' in to['canales']['canal_1']:
#              if 'k5_ch1' in to['canales']['canal_1']['aceleracion']:
#                 conf['k5_ch1']=to['canales']['canal_1']['aceleracion']['k5_ch1']
#              if 'k10_ch1' in to['canales']['canal_1']['aceleracion']:
#                 conf['k10_ch1']=to['canales']['canal_1']['aceleracion']['k10_ch1']
#             if 'velocidad' in to['canales']['canal_1']:
#              if 'h5_ch1' in to['canales']['canal_1']['velocidad']:
#                 conf['h5_ch1']=to['canales']['canal_1']['velocidad']['h5_ch1']
#              if 'k1_ch1' in to['canales']['canal_1']['velocidad']:
#                 conf['k1_ch1']=to['canales']['canal_1']['velocidad']['k1_ch1']
#         if int(conf['Nro_canales'])>=2:
#             conf['nombre_ch2']=to['canales']['canal_2']['nombre']
#             conf['direccion_ch2']=to['canales']['canal_2']['direccion']
#             conf['ganancia_ch2']=to['canales']['canal_2']['ganancia']
#             if 'aceleracion' in to['canales']['canal_2']:
#              if 'k5_ch2' in to['canales']['canal_2']['aceleracion']:
#                 conf['k5_ch2']=to['canales']['canal_2']['aceleracion']['k5_ch2']
#              if 'k10_ch2' in to['canales']['canal_2']['aceleracion']:
#                 conf['k10_ch2']=to['canales']['canal_2']['aceleracion']['k10_ch2']
#             if 'velocidad' in to['canales']['canal_2']:
#              if 'h5_ch2' in to['canales']['canal_2']['velocidad']:
#                 conf['h5_ch2']=to['canales']['canal_2']['velocidad']['h5_ch2']
#              if 'k1_ch2' in to['canales']['canal_2']['velocidad']:
#                 conf['k1_ch2']=to['canales']['canal_2']['velocidad']['k1_ch2']
#         if int(conf['Nro_canales'])>=3:
#             conf['nombre_ch3']=to['canales']['canal_3']['nombre']
#             conf['direccion_ch3']=to['canales']['canal_3']['direccion']
#             conf['ganancia_ch3']=to['canales']['canal_3']['ganancia']
#             if 'aceleracion' in to['canales']['canal_3']:
#              if 'k5_ch3' in to['canales']['canal_3']['aceleracion']:
#                 conf['k5_ch3']=to['canales']['canal_3']['aceleracion']['k5_ch3']
#              if 'k10_ch3' in to['canales']['canal_3']['aceleracion']:
#                 conf['k10_ch3']=to['canales']['canal_3']['aceleracion']['k10_ch3']
#             if 'velocidad' in to['canales']['canal_3']:
#              if 'h5_ch3' in to['canales']['canal_3']['velocidad']:
#                 conf['h5_ch3']=to['canales']['canal_3']['velocidad']['h5_ch3']
#              if 'k1_ch3' in to['canales']['canal_3']['velocidad']:
#                 conf['k1_ch3']=to['canales']['canal_3']['velocidad']['k1_ch3']
#         if int(conf['Nro_canales'])==4:
#             conf['nombre_ch4']=to['canales']['canal_4']['nombre']
#             conf['direccion_ch4']=to['canales']['canal_4']['direccion']
#             conf['ganancia_ch4']=to['canales']['canal_4']['ganancia']
#             if 'aceleracion' in to['canales']['canal_4']:
#              if 'k5_ch4' in to['canales']['canal_4']['aceleracion']:
#                 conf['k5_ch4']=to['canales']['canal_4']['aceleracion']['k5_ch4']
#              if 'k10_ch4' in to['canales']['canal_4']['aceleracion']:
#                 conf['k10_ch4']=to['canales']['canal_4']['aceleracion']['k10_ch4']
#             if 'velocidad' in to['canales']['canal_4']:
#              if 'h5_ch4' in to['canales']['canal_4']['velocidad']:
#                 conf['h5_ch4']=to['canales']['canal_4']['velocidad']['h5_ch4']
#              if 'k1_ch4' in to['canales']['canal_4']['velocidad']:
#                 conf['k1_ch4']=to['canales']['canal_4']['velocidad']['k1_ch4']
#         return render_template('static_config.html',conf=conf)

#    if request.method == 'GET':
#         conf={}
#         to=ref.child(f"Configuraciones/{id_config}/").get()
#         conf['nombre']=to['maquina']['nombre']
#         conf['tipoSensor']=to['tipoSensor']
#         conf['Nro_canales']=to['Nro_canales']
#         conf['sensibilidadSensor']=to['sensibilidadSensor']
#         if int(conf['Nro_canales'])>=1:
#             conf['nombre_ch1']=to['canales']['canal_1']['nombre']
#             conf['direccion_ch1']=to['canales']['canal_1']['direccion']
#             conf['ganancia_ch1']=to['canales']['canal_1']['ganancia']
#             if 'aceleracion' in to['canales']['canal_1']:
#              if 'k5_ch1' in to['canales']['canal_1']['aceleracion']:
#                 conf['k5_ch1']=to['canales']['canal_1']['aceleracion']['k5_ch1']
#              if 'k10_ch1' in to['canales']['canal_1']['aceleracion']:
#                 conf['k10_ch1']=to['canales']['canal_1']['aceleracion']['k10_ch1']
#             if 'velocidad' in to['canales']['canal_1']:
#              if 'h5_ch1' in to['canales']['canal_1']['velocidad']:
#                 conf['h5_ch1']=to['canales']['canal_1']['velocidad']['h5_ch1']
#              if 'k1_ch1' in to['canales']['canal_1']['velocidad']:
#                 conf['k1_ch1']=to['canales']['canal_1']['velocidad']['k1_ch1']
#         if int(conf['Nro_canales'])>=2:
#             conf['nombre_ch2']=to['canales']['canal_2']['nombre']
#             conf['direccion_ch2']=to['canales']['canal_2']['direccion']
#             conf['ganancia_ch2']=to['canales']['canal_2']['ganancia']
#             if 'aceleracion' in to['canales']['canal_2']:
#              if 'k5_ch2' in to['canales']['canal_2']['aceleracion']:
#                 conf['k5_ch2']=to['canales']['canal_2']['aceleracion']['k5_ch2']
#              if 'k10_ch2' in to['canales']['canal_2']['aceleracion']:
#                 conf['k10_ch2']=to['canales']['canal_2']['aceleracion']['k10_ch2']
#             if 'velocidad' in to['canales']['canal_2']:
#              if 'h5_ch2' in to['canales']['canal_2']['velocidad']:
#                 conf['h5_ch2']=to['canales']['canal_2']['velocidad']['h5_ch2']
#              if 'k1_ch2' in to['canales']['canal_2']['velocidad']:
#                 conf['k1_ch2']=to['canales']['canal_2']['velocidad']['k1_ch2']
#         if int(conf['Nro_canales'])>=3:
#             conf['nombre_ch3']=to['canales']['canal_3']['nombre']
#             conf['direccion_ch3']=to['canales']['canal_3']['direccion']
#             conf['ganancia_ch3']=to['canales']['canal_3']['ganancia']
#             if 'aceleracion' in to['canales']['canal_3']:
#              if 'k5_ch3' in to['canales']['canal_3']['aceleracion']:
#                 conf['k5_ch3']=to['canales']['canal_3']['aceleracion']['k5_ch3']
#              if 'k10_ch3' in to['canales']['canal_3']['aceleracion']:
#                 conf['k10_ch3']=to['canales']['canal_3']['aceleracion']['k10_ch3']
#             if 'velocidad' in to['canales']['canal_3']:
#              if 'h5_ch3' in to['canales']['canal_3']['velocidad']:
#                 conf['h5_ch3']=to['canales']['canal_3']['velocidad']['h5_ch3']
#              if 'k1_ch3' in to['canales']['canal_3']['velocidad']:
#                 conf['k1_ch3']=to['canales']['canal_3']['velocidad']['k1_ch3']
#         if int(conf['Nro_canales'])==4:
#             conf['nombre_ch4']=to['canales']['canal_4']['nombre']
#             conf['direccion_ch4']=to['canales']['canal_4']['direccion']
#             conf['ganancia_ch4']=to['canales']['canal_4']['ganancia']
#             if 'aceleracion' in to['canales']['canal_4']:
#              if 'k5_ch4' in to['canales']['canal_4']['aceleracion']:
#                 conf['k5_ch4']=to['canales']['canal_4']['aceleracion']['k5_ch4']
#              if 'k10_ch4' in to['canales']['canal_4']['aceleracion']:
#                 conf['k10_ch4']=to['canales']['canal_4']['aceleracion']['k10_ch4']
#             if 'velocidad' in to['canales']['canal_4']:
#              if 'h5_ch4' in to['canales']['canal_4']['velocidad']:
#                 conf['h5_ch4']=to['canales']['canal_4']['velocidad']['h5_ch4']
#              if 'k1_ch4' in to['canales']['canal_4']['velocidad']:
#                 conf['k1_ch4']=to['canales']['canal_4']['velocidad']['k1_ch4'] 

#         return render_template('static_config.html',conf=conf)

# @app.route('/config-ch', methods=['GET', 'POST'])
# def config_ch():
#     return render_template('ch_config.html')




# if __name__== '__main__':
#     app.run(host='192.168.0.87', port=80,debug=True)